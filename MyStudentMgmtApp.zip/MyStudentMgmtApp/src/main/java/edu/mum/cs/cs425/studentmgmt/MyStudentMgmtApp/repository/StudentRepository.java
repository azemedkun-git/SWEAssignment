package edu.mum.cs.cs425.studentmgmt.MyStudentMgmtApp.repository;

import org.springframework.data.repository.CrudRepository;

import edu.mum.cs.cs425.studentmgmt.MyStudentMgmtApp.model.Student;

public interface StudentRepository extends CrudRepository<Student, Long> {

}
