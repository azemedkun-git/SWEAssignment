package edu.mum.cs.cs425.studentmgmt.MyStudentMgmtApp.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long studentId;
	@NotBlank
	private String studentNumber;
	@NotBlank
	private String firstNmae;
	private String middleName;
	@NotBlank
	private String lastName;
	private double cgpa;
	@DateTimeFormat(pattern ="yyyy-mm-dd")
	private LocalDate dateOfEnrollment;
	
	public Student() {
	}
	
	public Student(@NotBlank String studentNumber, @NotBlank String firstNmae, String middleName,
			@NotBlank String lastName, double cgpa, LocalDate dateOfEnrollment) {
		super();
		this.studentNumber = studentNumber;
		this.firstNmae = firstNmae;
		this.middleName = middleName;
		this.lastName = lastName;
		this.cgpa = cgpa;
		this.dateOfEnrollment = dateOfEnrollment;
	}

	public Student(long studentId, @NotBlank String studentNumber, @NotBlank String firstNmae, String middleName,
			@NotBlank String lastName, double cgpa, LocalDate dateOfEnrollment) {
		super();
		this.studentId = studentId;
		this.studentNumber = studentNumber;
		this.firstNmae = firstNmae;
		this.middleName = middleName;
		this.lastName = lastName;
		this.cgpa = cgpa;
		this.dateOfEnrollment = dateOfEnrollment;
	}

	public long getStudentId() {
		return studentId;
	}

	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}

	public String getStudentNumber() {
		return studentNumber;
	}

	public void setStudentNumber(String studentNumber) {
		this.studentNumber = studentNumber;
	}

	public String getFirstNmae() {
		return firstNmae;
	}

	public void setFirstNmae(String firstNmae) {
		this.firstNmae = firstNmae;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getCgpa() {
		return cgpa;
	}

	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}

	public LocalDate getDateOfEnrollment() {
		return dateOfEnrollment;
	}

	public void setDateOfEnrollment(LocalDate dateOfEnrollment) {
		this.dateOfEnrollment = dateOfEnrollment;
	}

	@Override
	public String toString() {
		return String.format(
				"Student [studentId=%s, studentNumber=%s, firstNmae=%s, middleName=%s, lastName=%s, cgpa=%s, dateOfEnrollment=%s]",
				studentId, studentNumber, firstNmae, middleName, lastName, cgpa, dateOfEnrollment);
	}
}
