package edu.mum.cs.cs425.studentmgmt.MyStudentMgmtApp.model;

import javax.persistence.Entity;

@Entity
public class Classroom {

}
