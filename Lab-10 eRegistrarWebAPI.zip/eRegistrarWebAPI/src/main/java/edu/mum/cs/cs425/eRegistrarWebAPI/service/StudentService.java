package edu.mum.cs.cs425.eRegistrarWebAPI.service;

import java.util.List;

import edu.mum.cs.cs425.eRegistrarWebAPI.model.Student;

public interface StudentService {
	public List<Student>listAllStudents();
	public void addStudent(Student student);
	public Student findStudentById(Integer id);
	public void deleteStudent(Integer id);
	public Student updateStudent(Student student);
}
