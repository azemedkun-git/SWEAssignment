package edu.mum.cs.cs425.eRegistrarWebAPI.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import edu.mum.cs.cs425.eRegistrarWebAPI.model.Student;
import edu.mum.cs.cs425.eRegistrarWebAPI.service.StudentService;

@RestController
public class StudentController {
	@Autowired
	private StudentService service;
	@GetMapping("/getall")
	public List<Student>listAllStudent(){
		return service.listAllStudents();
	}
	@PostMapping("/save")
	public void addStudent(@RequestBody Student student) {
		service.addStudent(student);
	}
	@GetMapping("/find/{id}")
	public Student findStudentById(@PathVariable Integer id) {
		return service.findStudentById(id);
	}
	@DeleteMapping("/delete/{studentId}")
	public void deleteStudent(@PathVariable Integer id) {
		service.deleteStudent(id);
	}
	@PutMapping("/update")
	public void updateStudent(@RequestBody Student student) {
		service.updateStudent(student);
	}
}
