package edu.mum.cs.cs425.eRegistrarWebAPI.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.mum.cs.cs425.eRegistrarWebAPI.model.Student;
import edu.mum.cs.cs425.eRegistrarWebAPI.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentRepository repository;
	@Override
	public List<Student> listAllStudents() {
		return repository.findAll(); 
	}

	@Override
	public void addStudent(Student student) {
		repository.save(student);
		
	}

	@Override
	public Student findStudentById(Integer id) {
		return repository.findById(id).orElse(null);
	}

	@Override
	public void deleteStudent(Integer id) {
		repository.deleteById(id);
		
	}

	@Override
	public Student updateStudent(Student student) {
		Student stud = repository.findById(student.getStudentId()).orElse(null);
		if(stud!=null) {
			student.getStudentNumber();
			stud.setStudentNumber(student.getStudentNumber());
			stud.setFirstName(student.getFirstName());
			stud.setMiddleName(student.getMiddleName());
			stud.setLastName(student.getLastName());
			stud.setCgpa(student.getCgpa());
			stud.setEnrollmentDate(student.getEnrollmentDate());
			stud.setIsInternational(student.getIsInternational());
			return repository.save(stud);
		}
		return null;
	}

}
