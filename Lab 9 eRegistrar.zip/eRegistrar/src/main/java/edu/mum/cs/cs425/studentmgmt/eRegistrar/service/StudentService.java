package edu.mum.cs.cs425.studentmgmt.eRegistrar.service;

import java.util.List;

import edu.mum.cs.cs425.studentmgmt.eRegistrar.model.Student;

public interface StudentService {
	public Iterable<Student>getAllStudents();
	public Student findStudent(Integer id);
	public Student saveStudent(Student student);
	//public Iterable<Student> getByIdStudents(String searchString);
	//public Iterable<Student> findByStudnetNumber(String searchString);
	public void deleteById(Integer id);
}
