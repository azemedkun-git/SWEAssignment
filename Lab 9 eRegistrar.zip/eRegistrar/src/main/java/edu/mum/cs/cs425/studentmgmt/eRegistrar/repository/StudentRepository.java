package edu.mum.cs.cs425.studentmgmt.eRegistrar.repository;

import java.time.LocalDate;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import edu.mum.cs.cs425.studentmgmt.eRegistrar.model.Student;
@Repository
public interface StudentRepository extends CrudRepository<Student, Integer> {
}
