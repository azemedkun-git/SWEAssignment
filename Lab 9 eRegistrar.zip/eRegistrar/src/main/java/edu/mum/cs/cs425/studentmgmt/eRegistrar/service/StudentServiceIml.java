package edu.mum.cs.cs425.studentmgmt.eRegistrar.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.mum.cs.cs425.studentmgmt.eRegistrar.model.Student;
import edu.mum.cs.cs425.studentmgmt.eRegistrar.repository.StudentRepository;
@Service
public class StudentServiceIml implements StudentService {
	StudentRepository studentRepository;
	@Autowired
	public StudentServiceIml(StudentRepository studentRepository) {
		this.studentRepository=studentRepository;
	}
	@Override
	public Iterable<Student> getAllStudents() {
		return studentRepository.findAll();
	}
	@Override
	public Student findStudent(Integer id) {
		return studentRepository.findById(id).get();
	}
	@Override
	public Student saveStudent(Student student) {
		return studentRepository.save(student);	
	}
//	@Override
//	public Iterable<Student> findByStudnetNumber(String searchString) {
//		studentRepository.f
//	}
	@Override
	public void deleteById(Integer id) {
		studentRepository.deleteById(id);
		
	}
}
