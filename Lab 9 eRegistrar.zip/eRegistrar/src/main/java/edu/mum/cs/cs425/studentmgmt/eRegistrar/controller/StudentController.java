package edu.mum.cs.cs425.studentmgmt.eRegistrar.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.mum.cs.cs425.studentmgmt.eRegistrar.model.Student;
import edu.mum.cs.cs425.studentmgmt.eRegistrar.service.StudentService;

@Controller
public class StudentController {
	private StudentService studentService;
	@Autowired
	public StudentController(StudentService studentService) {
		this.studentService=studentService;
	}
	@GetMapping(value = {"/","/index","/eRegistrar", "eRegistrar/home"})
	public String displayHomePage() {
		return "home/index";
	}

	@GetMapping(value = {"/eRegistrar/students/list", "students/list"})
	public ModelAndView displayAllStudents() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("students", studentService.getAllStudents());
		modelAndView.setViewName("students/list");
		return modelAndView;
	}
	
	@GetMapping(value = {"/eRegistrar/students/edit/{studentId}", "students/edit"})
	public String editStudent(@Valid @ModelAttribute("studentId") Integer id, Model model) {
		Student stud = studentService.findStudent(id);
		if(stud!=null) {
			model.addAttribute("student", stud);
			return "students/edit"; 
		}
		else
			return "students/list";
	}
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public String saveStudent(@ModelAttribute("student") Student student) {
		studentService.saveStudent(student);
		return"redirect:/students/list";
	}
	
	@GetMapping(value= {"/eRegistrar/students/delete/{studentId}"})
	public String deleteStudent(@PathVariable(name="studentId") Integer id) {
		studentService.deleteById(id);
		return"redirect:/students/list";
	}
}
