 package edu.miu.cs.cs425.lesson15.tddwithjunitdemos;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.hamcrest.CoreMatchers.is;

import edu.miu.cs.cs425.lesson15.tddwithjunitdemos.units.ISquareComputingService;
import edu.miu.cs.cs425.lesson15.tddwithjunitdemos.units.SumOfSquersComputer;

public class SumOfSquaresComputerTest {
	private SumOfSquersComputer sumOfSquersComputer;
	private ISquareComputingService squareComputingService = mock(ISquareComputingService.class);
	@Before
	public void setUp() throws Exception{
		this.sumOfSquersComputer = new SumOfSquersComputer(squareComputingService);
	}
	
	@After
	public void tearDown() throws Exception{
		this.sumOfSquersComputer = null;
	}
	@Test
	public void testComputeSumOfSquares() {
		when(squareComputingService.computeSquares(new Integer[] {1, 2, 3}))
			.thenReturn(new Integer[] {1, 4, 9});
		Integer actual = sumOfSquersComputer.computeSumOfSquares(new Integer[] {1, 2, 3});
		Integer expected = 14;
		assertEquals(expected, actual); 
		assertThat(actual, is(expected));
	}
	@Test
	public void testComputeSumOfSquaresboundary() {
		
	}

}
