package edu.miu.cs.cs425.lesson15.tddwithjunitdemos;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.miu.cs.cs425.lesson15.tddwithjunitdemos.units.CalculatorApp;

public class CalculatorTest {
	
	private CalculatorApp calculatorApp;

	@Before
	public void setUp() throws Exception {
		this.calculatorApp = new CalculatorApp();
	}

	@After
	public void tearDown() throws Exception {
		this.calculatorApp=null;
	}

	@Test
	public void testAdd() {
		Integer inputA = 1;
		Integer inputB = 2;
		Integer expected = 3;
		Integer actual = this.calculatorApp.add(inputA, inputB);
		assertEquals(expected, actual);
	}
	
	@Test
	public void testAddForNulls() {
		Integer inpputA = null;
		Integer inputB = null;
		Integer expected = this.calculatorApp.add(inpputA, inputB);
		Integer actual = null;
		assertEquals(expected, actual);
	}
}
