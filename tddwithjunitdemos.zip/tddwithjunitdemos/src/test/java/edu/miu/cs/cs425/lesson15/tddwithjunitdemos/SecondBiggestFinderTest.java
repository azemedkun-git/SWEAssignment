package edu.miu.cs.cs425.lesson15.tddwithjunitdemos;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.miu.cs.cs425.lesson15.tddwithjunitdemos.units.SecondBiggestFinder;

public class SecondBiggestFinderTest {
	private SecondBiggestFinder secondBiggestFinderTest;
	@Before
	public void setUp() throws Exception {
		this.secondBiggestFinderTest = new SecondBiggestFinder();
	}

	@After
	public void tearDown() throws Exception {
		this.secondBiggestFinderTest=null;
	}

	@Test
	public void testFindSecondBiggest() {
		Integer[] input = new Integer[] {1, 2, 3, 4, 5};
		Integer expected = 4;
		Integer actual = this.secondBiggestFinderTest.findSecondBiggest(input);
		assertEquals(expected, actual);
	}
	@Test
	public void testFindSecondBiggestEmptyArray() {
		Integer[] input = new Integer[] {};
		Integer expected = null;
		Integer actual = this.secondBiggestFinderTest.findSecondBiggest(input);
		assertEquals(expected, actual);
	}
	@Test
	public void testFindSecondBiggestOneArray() {
		Integer[] input = new Integer[] {5};
		Integer expected = null;
		Integer actual = this.secondBiggestFinderTest.findSecondBiggest(input);
		assertEquals(expected, actual);
	}

}
