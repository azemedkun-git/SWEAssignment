package edu.miu.cs.cs425.lesson15.tddwithjunitdemos.units;

public class CalculatorApp {

	public CalculatorApp() {
		
	}
	public Integer add(Integer a, Integer b) {
		if(a== null || b==null)
			return null;
		return a + b;
	}

}
