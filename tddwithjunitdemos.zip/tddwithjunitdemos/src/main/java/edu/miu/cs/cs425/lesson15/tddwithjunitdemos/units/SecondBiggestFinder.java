package edu.miu.cs.cs425.lesson15.tddwithjunitdemos.units;

public class SecondBiggestFinder {

	public SecondBiggestFinder() {
		
	}
	public Integer findSecondBiggest(Integer[] a) {
		if(a.length<2) {
			return null;
		}
		Integer b = a[0] >a[1]? a[0]:a[1];
		Integer sb = (b==a[0])? a[1]:a[0];
		for(int i=2; i<a.length; i++) {
			if(a[i] > b) {
				Integer temp = b;
				b=a[i];
				sb = temp;
			}else if(a[i] > sb) {
				sb=a[i];
			}
		}
		return sb;
	}

}
