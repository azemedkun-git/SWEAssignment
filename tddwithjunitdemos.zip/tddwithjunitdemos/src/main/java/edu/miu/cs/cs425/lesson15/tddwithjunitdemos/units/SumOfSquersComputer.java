package edu.miu.cs.cs425.lesson15.tddwithjunitdemos.units;

import java.util.Arrays;

public class SumOfSquersComputer {
	private ISquareComputingService squareComputingService;
	public SumOfSquersComputer( ISquareComputingService squareComputingService) {
		this.squareComputingService = squareComputingService;
	}
	
	public Integer computeSumOfSquares(Integer[] ints) {
		Integer[] squares = squareComputingService.computeSquares(ints);
		for(int i=0; i<squares.length; i++)
			System.out.println("dfdfsfs" + squares[i]);
		//Integer[] squares = (Integer[])Arrays.stream(ints).map(n->n*n).toArray();
		//Integer[] squares = new Integer[] {1, 2, 3, 4};
		return Arrays.stream(squares).reduce((n, m)->n + m).orElse(null);
	}
}
