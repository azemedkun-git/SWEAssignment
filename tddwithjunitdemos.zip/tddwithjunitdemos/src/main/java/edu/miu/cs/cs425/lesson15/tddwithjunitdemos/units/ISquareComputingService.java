package edu.miu.cs.cs425.lesson15.tddwithjunitdemos.units;

public interface ISquareComputingService {
Integer[] computeSquares(Integer[] ints);
}
